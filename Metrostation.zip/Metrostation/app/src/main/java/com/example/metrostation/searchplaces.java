package com.example.metrostation;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

public class searchplaces extends AppCompatActivity implements JsonResponse, AdapterView.OnItemClickListener {
    EditText e1, e2;
    Button b1;
    ListView l1;

    String[] fplaces,tplaces,types,amounts,value,time,requestdetails_id;
    String search, status, method, se;
    public static String amt, rid, tlongi, count;
    SharedPreferences sh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_searchplaces);

        e1 = (EditText) findViewById(R.id.e1);

        e2 = (EditText) findViewById(R.id.e2);
        b1 = (Button) findViewById(R.id.button);

        l1=(ListView)findViewById(R.id.lv) ;
        l1.setOnItemClickListener(this);
        sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

        JsonReq JR = new JsonReq();
        JR.json_response = (JsonResponse) searchplaces.this;
        String q = "/viewsearchplace";
        q = q.replace(" ", "%20");
        JR.execute(q);


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                search = e1.getText().toString();
                se = e2.getText().toString();


                JsonReq JR = new JsonReq();
                JR.json_response = (JsonResponse) searchplaces.this;
                String q = "/searchplace?&search=" + search + "&se=" + se;
                q = q.replace(" ", "%20");
                JR.execute(q);
            }
        });

//        e1.addTextChangedListener(new TextWatcher() {
//            @Override
//            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//
//            }
//
//            @Override
//            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//
//            }
//
//            @Override
//            public void afterTextChanged(Editable editable) {
//
//
//
//            }
//        });
    }

    @Override
    public void response(JSONObject jo) {
        try {


            status = jo.getString("status");
            Log.d("pearlssssss", status);


            if (status.equalsIgnoreCase("success")) {
                l1.setVisibility(View.VISIBLE);
                JSONArray ja1 = (JSONArray) jo.getJSONArray("data");
                fplaces = new String[ja1.length()];
                tplaces = new String[ja1.length()];
                types = new String[ja1.length()];
                time= new String[ja1.length()];
                requestdetails_id= new String[ja1.length()];
                amounts = new String[ja1.length()];
                value = new String[ja1.length()];

                value = new String[ja1.length()];

                for (int i = 0; i < ja1.length(); i++) {
                    fplaces[i] = ja1.getJSONObject(i).getString("fplaces");
                    tplaces[i] = ja1.getJSONObject(i).getString("tplaces");
                    types[i] = ja1.getJSONObject(i).getString("types");
                    requestdetails_id[i] = ja1.getJSONObject(i).getString("requestdetails_id");
                    amounts[i] = ja1.getJSONObject(i).getString("amounts");
                    time[i] = ja1.getJSONObject(i).getString("rates");

                    value[i] = "From place:" + fplaces[i] + "\nTo place:" + tplaces[i] + "\nTypes:" + types[i]+ "\nAmounts:" + amounts[i]+ "\nTimes:" + time[i];

                }
                ArrayAdapter<String> ar = new ArrayAdapter<String>(getApplicationContext(), R.layout.custtext, value);

                l1.setAdapter(ar);



            }
            else{
                Toast.makeText(getApplicationContext(),"No Data",Toast.LENGTH_LONG).show();
                l1.setVisibility(View.GONE);
            }



        }

        catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();

        }




    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        amt=amounts[i];
        rid=requestdetails_id[i];



            final CharSequence[] items = {"Pay Now", "Cancel"};

            AlertDialog.Builder builder = new AlertDialog.Builder(searchplaces.this);
            builder.setItems(items, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int item) {

                    if (items[item].equals("Pay Now")) {


                        startActivity(new Intent(getApplicationContext(), Makepayment.class));


                    }
                }

            });
            builder.show();






    }
}