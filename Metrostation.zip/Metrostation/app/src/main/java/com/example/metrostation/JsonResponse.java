package com.example.metrostation;

import org.json.JSONObject;

public interface JsonResponse {
	public void response(JSONObject jo);
}
