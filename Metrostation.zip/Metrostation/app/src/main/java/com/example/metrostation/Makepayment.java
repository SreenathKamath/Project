package com.example.metrostation;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONObject;

public class Makepayment extends AppCompatActivity implements JsonResponse {
    EditText e,ecard,ecvv,edate;
    Button b;
    String amt,card,cvv,dt;
    SharedPreferences sh;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_makepayment);
        e=(EditText)findViewById(R.id.editText1);
        ecard=(EditText)findViewById(R.id.editText2);
        ecvv=(EditText)findViewById(R.id.editText3);
        edate=(EditText)findViewById(R.id.editText4);
        e.setText(searchplaces.amt+"");
        e.setEnabled(false);
        b=(Button)findViewById(R.id.button1);
        b.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                amt=e.getText().toString();
                card=ecard.getText().toString();
                cvv=ecvv.getText().toString();
                dt=edate.getText().toString();

                if(card.equalsIgnoreCase(""))
                {

                    ecard.setError("enter card number");
                    ecard.setFocusable(true);

                }
                else if(card.length()!=16)
                {

                    ecard.setError("enter valid card number(16 digit)");
                    ecard.setFocusable(true);

                }
                else if(cvv.equalsIgnoreCase(""))
                {

                    ecvv.setError("enter your cvv");
                    ecvv.setFocusable(true);

                }
                else if(cvv.length()!=3)
                {

                    ecvv.setError("enter valid cvv (3 digit)");
                    ecvv.setFocusable(true);

                }
                else if(dt.equalsIgnoreCase(""))
                {

                    edate.setError("enter valid date");
                    edate.setFocusable(true);

                }

                else
                {
                    JsonReq JR=new JsonReq();
                    JR.json_response=(JsonResponse)Makepayment.this;
                    String q = "/Makepayment?logid="+login.logid+"&amt="+amt+"&rid="+searchplaces.rid;
                    q=q.replace(" ","%20");
                    JR.execute(q);

                }
            }
        });


    }

    @Override
    public void response(JSONObject jo) {
        try {


            String status = jo.getString("status");
            Log.d("pearl", status);


            if (status.equalsIgnoreCase("success")) {
                Toast.makeText(getApplicationContext(), "PAID SUCCESSFULLY", Toast.LENGTH_LONG).show();
                startActivity(new Intent(getApplicationContext(), Userhome.class));

            } else {

                Toast.makeText(getApplicationContext(), " failed.TRY AGAIN!!", Toast.LENGTH_LONG).show();
            }



        }

        catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
        }
    }
    public void onBackPressed()
    {
        // TODO Auto-generated method stub
        super.onBackPressed();
        Intent b=new Intent(getApplicationContext(),Userhome.class);
        startActivity(b);
    }
    }
